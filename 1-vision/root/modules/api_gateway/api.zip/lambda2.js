module.exports.handler = (event) => {
    console.log("event", event)
    return "ok"
}